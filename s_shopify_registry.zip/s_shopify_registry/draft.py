window.lcRegistryId,
updateLCItemTable
renderLCItemTable


/gift-registry/view/4

https://hanetest2.myshopify.com/apps/gift-registry/view/4

(base) thuy@thuy-XPS-15-9550:~/work/tool$ find /home -type f  -name bundle.js
/home/thuy/Qt5.14.0/Tools/QtCreator/share/qtcreator/qbs/share/qbs/modules/bundle/bundle.js
/home/thuy/Qt5.14.0/5.14.0/Src/qtwebengine/src/3rdparty/chromium/third_party/devtools-node-modules/third_party/node_modules/ajv/scripts/bundle.js
/home/thuy/Downloads/FireShot/feed-for-tiktok/vendor/htmlburger/carbon-field-number/build/bundle.js
/home/thuy/Music/whatsapp-developer/static/src/js/bundle.js
/home/thuy/.local/share/Trash/expunged/453941521/whatsapp/static/src/js/bundle.js
/home/thuy/.cache/yarn/v6/npm-stylable-5.4.11-a54fbd0cad902b5f98f3d01227b63527a6a9a4d7-integrity/node_modules/stylable/dist/src/bundle.js
/home/thuy/.cache/yarn/v6/npm-vm-browserify-1.1.2-78641c488b8e6ca91a75f511e7a3b32a86e5dda0-integrity/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/.cache/yarn/v6/npm-ajv-6.5.3-71a569d189ecf4f4f321224fecb166f071dd90f9-integrity/node_modules/ajv/scripts/bundle.js
/home/thuy/.cache/yarn/v6/npm-crypto-browserify-3.12.0-396cf9f3137f03e4b8e532c58f698254e00f80ec-integrity/node_modules/crypto-browserify/example/bundle.js
/home/thuy/.cache/yarn/v6/npm-ajv-6.12.3-18c5af38a111ddeb4f2697bd78d68abc1cabd706-integrity/node_modules/ajv/scripts/bundle.js
/home/thuy/.cache/yarn/v6/npm-module-deps-6.2.2-d8a15c2265dfc119153c29bb47386987d0ee423b-integrity/node_modules/module-deps/test/bundle.js
/home/thuy/.cache/yarn/v6/npm-labeled-stream-splicer-2.0.2-42a41a16abcd46fd046306cf4f2c3576fffb1c21-integrity/node_modules/labeled-stream-splicer/test/bundle.js
/home/thuy/.cache/yarn/v6/npm-labeled-stream-splicer-2.0.2-42a41a16abcd46fd046306cf4f2c3576fffb1c21-integrity/node_modules/labeled-stream-splicer/example/bundle.js
/home/thuy/.cache/yarn/v6/npm-browserify-16.5.0-a1c2bc0431bec11fd29151941582e3f645ede881-integrity/node_modules/browserify/test/bundle.js
/home/thuy/.cache/yarn/v6/npm-browserify-16.5.0-a1c2bc0431bec11fd29151941582e3f645ede881-integrity/node_modules/browserify/example/source_maps/js/build/bundle.js
/home/thuy/.cache/typescript/3.5/node_modules/ajv/scripts/bundle.js
find: ‘/home/thuy/.cache/dconf’: Permission denied
/home/thuy/work/shopifyodoo/odoo-13.0/customaddons/whatsapp/static/src/js/bundle.js
/home/thuy/work/shopifyodoo/odoo14/doc/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/shopifyodoo/odoo14/rd/whatsapp-developer/static/src/js/bundle.js
/home/thuy/work/shopifyodoo/odoo131/customaddons/whatsapp/static/src/js/bundle.js
/home/thuy/work/shopifyodoo/odoo131/customaddons/whatsappfromserver/whatsapp/static/src/js/bundle.js
/home/thuy/work/odoo-14.0/doc/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/proj/odoofy/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/proj/flexfit/site/odoo_flexfit-developer/customaddons/whatsapp/static/src/js/bundle.js
/home/thuy/work/proj/refund_doo_marketplace/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/proj/shopify/sampleapp/sample-embedded-app/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/proj/shopify/sampleapp/sample-embedded-app/node_modules/ajv/scripts/bundle.js
/home/thuy/work/proj/shopify/sampleapp/sample-embedded-app/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/proj/shopify/trello/odoo/customaddons/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/proj/shopify/sticky/sticky-cart/app/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/proj/shopify/sticky/sticky-cart/app/node_modules/ajv/scripts/bundle.js
/home/thuy/work/proj/shopify/sticky/sticky-cart/app/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/proj/wix/bookings-list-sample-application-master/client/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/proj/wix/bookings-list-sample-application-master/client/node_modules/serve/node_modules/ajv/scripts/bundle.js
/home/thuy/work/proj/wix/bookings-list-sample-application-master/client/node_modules/ajv/scripts/bundle.js
/home/thuy/work/proj/wix/bookings-list-sample-application-master/client/node_modules/stylable/dist/src/bundle.js
/home/thuy/work/proj/wix/bookings-list-sample-application-master/client/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/proj/wix/sample-wix-rest-app-master/node_modules/ajv/scripts/bundle.js
/home/thuy/work/shopify/gitlab/whatsapp/customaddons/whatsapp/views/static/src/js/bundle.js
/home/thuy/work/shopify/gitlab/whatsapp/customaddons/whatsapp/static/src/js/bundle.js
/home/thuy/work/shopify/saoapp/doc/whatsapp-awhatsapp-0110/static/src/js/bundle.js
/home/thuy/work/shopify/sample/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/shopify/sample/node_modules/module-deps/test/bundle.js
/home/thuy/work/shopify/sample/node_modules/browserify/test/bundle.js
/home/thuy/work/shopify/sample/node_modules/browserify/example/source_maps/js/build/bundle.js
/home/thuy/work/shopify/sample/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/shopify/sample/node_modules/labeled-stream-splicer/test/bundle.js
/home/thuy/work/shopify/sample/node_modules/labeled-stream-splicer/example/bundle.js
/home/thuy/work/shopify/shopify_app/static/src/js/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/node-libs-browser/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/percy-client/dist/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/serve/node_modules/ajv/scripts/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/ajv/scripts/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/node_modules/dom-walk/example/static/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/module-deps/test/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/browserify/test/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/browserify/example/source_maps/js/build/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/crypto-browserify/example/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/labeled-stream-splicer/test/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/browserify/node_modules/labeled-stream-splicer/example/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/webpack/node_modules/vm-browserify/example/run/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/webpack/node_modules/ajv/scripts/bundle.js
/home/thuy/work/shopify/polarisrepo/polaris-react/examples/webpack/node_modules/crypto-browserify/example/bundle.js
find: ‘/home/thuy/.gvfs’: Permission denied
find: ‘/home/thuy/.dbus’: Permission denied
/home/thuy/.vscode/extensions/ikappas.phpcs-1.0.5/node_modules/ajv/scripts/bundle.js
find: ‘/home/thuyluu/.gnupg’: Permission denied
find: ‘/home/thuyluu/.local’: Permission denied
find: ‘/home/thuyluu/.cache’: Permission denied
find: ‘/home/thuyluu/.config’: Permission denied
find: ‘/home/thuyluu/.gconf’: Permission denied
find: ‘/home/thuyluu/.nv’: Permission denied
find: ‘/home/.ecryptfs/thuy/.Private/ECRYPTFS_FNEK_ENCRYPTED.FWY1aSQ-rhOKRUTw3BHxDEklaOonuLDCLM4PTHaRab1dnnhblOUUR3wnAk--’: Permission denied
find: ‘/home/.ecryptfs/thuy/.Private/ECRYPTFS_FNEK_ENCRYPTED.FWY1aSQ-rhOKRUTw3BHxDEklaOonuLDCLM4PZo0b6wuBefa09b1Ypzr1JE--/ECRYPTFS_FNEK_ENCRYPTED.FWY1aSQ-rhOKRUTw3BHxDEklaOonuLDCLM4P65ICdGP7r11zFBNB7IDCrk--’: Permission denied
(base) thuy@thuy-XPS-15-9550:~/work/tool$

--------------------------------------------------------
(base) thuy@thuy-XPS-15-9550:~/work/tool$ find /opt -type f  -name bundle.js
/opt/odoo121/odoo/customaddons/shopify_app/static/src/js/bundle.js
/opt/odoo13/odoo/enterpriseaddons/mrp_mps/static/src/js/bundle.js
/opt/odoo13/odoo/customaddons/whatsapp/static/src/js/bundle.js
find: ‘/opt/containerd’: Permission denied
find: ‘/opt/doo132/.local/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/.local/share/Odoo/addons’: Permission denied
find: ‘/opt/doo132/.local1/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/.local1/share/Odoo/addons’: Permission denied
find: ‘/opt/doo132/odoo/.local/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/odoo/.local/share/Odoo/addons’: Permission denied
find: ‘/opt/doo132/odoo/.local1/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/odoo/.local1/share/Odoo/addons’: Permission denied
find: ‘/opt/doo132/odoo/.local2/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/odoo/.local2/share/Odoo/addons’: Permission denied
find: ‘/opt/doo132/.local2/share/Odoo/sessions’: Permission denied
find: ‘/opt/doo132/.local2/share/Odoo/addons’: Permission denied
/opt/odooclone13/odoo/enterpriseaddons/mrp_mps/static/src/js/bundle.js
/opt/odooclone13/odoo/customaddons/whatsapp/static/src/js/bundle.js
(base) thuy@thuy-XPS-15-9550:~/work/tool$


/home/thuy/work/proj/shopify/sticky/sticky-cart/app/src/App.js
/home/thuy/work/shopify/sample/src/App.js
/opt/odoo13/odoo/customaddons/sticky-cart/app/src/App.js



