<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wpapp' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', 'root' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '+OUhsp.Fn<5+CAM B>oA>+`7:QC(cpL|p32h6Z.Y~~SA=G}0%b1qQAW$Gh$X#yS$' );
define( 'SECURE_AUTH_KEY',  '(}A6UqXfRQ+$2*U@)c-19;}#L3Z(s8|{H!i$1kKeuu2,%2R*IH.p<xf-V*f;dTIn' );
define( 'LOGGED_IN_KEY',    'fO^Xd0Z_K]GGc ^C:i4hRh_iTc[6*,I.<T7%fd~+W[;5+&El`$=^+x5o$2OgnD! ' );
define( 'NONCE_KEY',        '&1BGu:+3Rs9sk>.+JXN2B#&/M`l3f/Q94XH,]OMV,3Y.zS[e,t+*bo`W)Ve{@8/m' );
define( 'AUTH_SALT',        '*$Ecc2CEK4{`I&w?-$k?oz/_xCFd@Hh*#nS$0-bZKy0LX;8&BTxKWh-ST0kZcj-:' );
define( 'SECURE_AUTH_SALT', '9Jsh :O.kH~cU$N%j}U*jsI[GxwpmJOkD)rmY=(Oe9be=!m1$M$sU=!kPxvI^{d3' );
define( 'LOGGED_IN_SALT',   ';J-4Qt!`5~VJBDcK&%(>x,b^}GN;+i@7jITm4^hM|;ZMz8-Eqe@y0&5)%Wxqm,Y#' );
define( 'NONCE_SALT',       'Yebve9eWCXpQ:&LfZ._<=<#$@iNy,~g7 /^|+TDF}, _K);r@/g*@{./AM(~3>ES' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG',false );
define('WP_DEBUG_LOG',true);
define('WP_SAMESITE_COOKIE','None');
define('WP_HOME', 'https://app.thexseed.com/blog/');
define('WP_SITEURL', 'https://app.thexseed.com/blog/');

$_SERVER['REQUEST_URI'] = str_replace("/wp-admin/", "/blog/wp-admin/",  $_SERVER['REQUEST_URI']);
if (isset($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') {
	    $_SERVER['HTTPS'] = 'on';
}

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
