<?php if ( ! defined( 'ABSPATH' ) ) { die; } // Cannot access pages directly.

