<?php

function appart_thimify_include_icons() {
	return array_keys(appart_thimify_icons());
}

function appart_font_awesome_icons_include() {
	return array_values(appart_font_awesome_icons_array());
}