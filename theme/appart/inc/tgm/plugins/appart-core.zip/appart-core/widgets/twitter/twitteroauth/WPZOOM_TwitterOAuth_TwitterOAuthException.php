<?php

if (!class_exists('WPZOOM_TwitterOAuthException')):
/**
 * @author Abraham Williams <abraham@abrah.am>
 */
class WPZOOM_TwitterOAuthException extends Exception
{
}
endif;
