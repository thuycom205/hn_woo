<?php

namespace Mas\Whatsapp\Admin;

class WhatsappMessage
{

}