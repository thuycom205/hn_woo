<?php
// Toolkit Page Title Addons
require_once( dirname(__FILE__) . '/shortcode/title.php');
// Toolkit Button Addons
require_once( dirname(__FILE__) . '/shortcode/button.php');
// Toolkit Button Addons
require_once( dirname(__FILE__) . '/shortcode/big-button.php');
// Toolkit Title Addons
require_once( dirname(__FILE__) . '/shortcode/text-box.php');
// Toolkit Feature Box Items Addons
require_once( dirname(__FILE__) . '/shortcode/feature.php');
// Toolkit Counter Box Addons
require_once( dirname(__FILE__) . '/shortcode/counter.php');
// Toolkit Testional Addons
require_once( dirname(__FILE__) . '/shortcode/testimonial.php');
// Toolkit Team Addons
require_once( dirname(__FILE__) . '/shortcode/team.php');
// Toolkit Blog Addons
require_once( dirname(__FILE__) . '/shortcode/blog.php');
// Toolkit Price Addons
require_once( dirname(__FILE__) . '/shortcode/price.php');
// Toolkit Image Carousel Addons
require_once( dirname(__FILE__) . '/shortcode/image-carousel.php');
// Toolkit Lightbox Addons
require_once( dirname(__FILE__) . '/shortcode/lightbox.php');